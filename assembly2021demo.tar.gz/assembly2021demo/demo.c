/*
 *  plasma.c
 *  Patater Demo Kit
 *
 *  Created by Jaeden Amero on 2016-06-17.
 *  Copyright 2016. SPDX-License-Identifier: MIT
 *
 */

//#include "plasmpal.h"
#include <SDL2/SDL.h>
#include <math.h>
#include <stdlib.h>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

//#define CAP_SPEED 1
#define WIDTH 640
#define HEIGHT 480
#define PRINT_FPS 0

#ifndef __EMSCRIPTEN__
#if CAP_SPEED
static size_t speed = 30;
#endif
#endif

static size_t width;
static size_t height;
static SDL_Window *window;
static SDL_Surface *screen;
static SDL_Surface *surface;
static uint8_t *pixels;
int gameover = 0;

//
static int *sin_buf = NULL;
static int byte_l_sin_buf = 0;
static int int_l_sin_buf;

//
void create_surface(void)
{
    surface = SDL_CreateRGBSurface(0, width, height, 32, 0, 0, 0, 0);

//    SDL_SetPaletteColors(surface->format->palette, plasma_palette, 0, 256);

    pixels = surface->pixels;

    /* Update the screen with the new surface. */
    SDL_BlitSurface(surface, NULL, screen, NULL);
}

static void initialize_plasma(void)
{
    int i,i2;
    double f1,f2;

    //
    byte_l_sin_buf = 65536*sizeof(int);
    int_l_sin_buf = 65536;
    sin_buf = malloc(byte_l_sin_buf);
    
    for(i=0,f1=0; i<int_l_sin_buf; i++,f1+=.01)
    {
        sin_buf[i] = 128+(127*sin(f1));
    }
    
    
    //
//            pixels[y * surface->pitch + x] =

    SDL_BlitSurface(surface, NULL, screen, NULL);
}

//
static int Render(void)
{
    int i,i2,i3,i4,ad,ad2,c,c2,x,y,new_x,new_y,fullcolour,posx,posy;
    static int cyc = 0;
    double fx,fy,fz;
    static double fposx = 0, fposy = 0;
    
    //
//    cyc = mach_absolute_time();
    cyc = SDL_GetTicks()/2;
    
    //
    posx = 128+(127*sin(fposx));
    posy = 128+(127*sin(fposy));
    //
    fposx += .05;
    fposy += .055;
    
    //
    for(y=0; y<height; y++)
    {
        ad = y*WIDTH*4;
        
        for(x=0; x<WIDTH; x++)
        {
            // depth
            fz = ((HEIGHT-y)*4)  +  sin_buf[ (sin_buf[(x+posx)%int_l_sin_buf] + sin_buf[(y+posy)%int_l_sin_buf]+cyc) % int_l_sin_buf] & 255;
            fz=fz / HEIGHT;
            // simulate depth
            fx = (x-(WIDTH/2));
            fx = fx / fz;
            fy = y; fy=fy/fz;
            new_x = fx;
            new_y = fy;
            
            c = sin_buf[(new_x + cyc) % int_l_sin_buf] + sin_buf[(new_y + cyc) % int_l_sin_buf] + cyc;

            // >>
            fullcolour = (c & 255) + ((c&255)<<8) | ((c&255)<<16);
        
            pixels[ad+(x<<2)+0] = (fullcolour)&255;
            pixels[ad+(x<<2)+1] = (fullcolour>>8)&255;
            pixels[ad+(x<<2)+2] = (fullcolour>>16)&255;
        }
    }

    //
    cyc++;
    
    //
    return 0;    
}

//
static void gameloop(void)
{
    static size_t heartbeat = 0;
    SDL_Event event;
    if (SDL_PollEvent(&event))
    {
        if (event.type == SDL_QUIT)
        {
            gameover = 1;
        }
        else if (event.type == SDL_WINDOWEVENT)
        {
            switch (event.window.event)
            {
                case SDL_WINDOWEVENT_RESIZED:
                case SDL_WINDOWEVENT_SIZE_CHANGED:
                    width = event.window.data1;
                    height = event.window.data2;

                    SDL_FreeSurface(screen);
                    screen = SDL_GetWindowSurface(window);

                    SDL_FreeSurface(surface);
                    create_surface();

                    //initialize_plasma();

                    break;
                default:
                    break;
            }
        }
        else if (event.type == SDL_KEYDOWN)
        {
            switch (event.key.keysym.sym)
            {
                case SDLK_ESCAPE:
                    gameover = 1;
                    break;

                default:
                    break;
            }
        }
    }

#if PRINT_FPS
    if (heartbeat % 1000 == 0)
    {
        float fps = (frames / (float)(SDL_GetTicks() - start_time)) * 1000;
        printf("FPS: %f\n", fps);
    }
#endif

#ifndef __EMSCRIPTEN__
#if CAP_SPEED
    if (heartbeat % speed == 0)
#endif
#endif
    {
        //
        Render();

        /* Copying the surface to the screen is unfortunately needed,
         * because real paletted hardware is hard to come by these days. */
        SDL_BlitSurface(surface, NULL, screen, NULL);

        SDL_UpdateWindowSurface(window);
#if PRINT_FPS
        ++frames;
#endif
    }

    ++heartbeat;
}

//
int main(int argc, char *argv[])
{
#if PRINT_FPS
    static size_t frames = 0;
    Uint32 start_time;
#endif

    (void)argc;
    (void)argv;

    SDL_Init(SDL_INIT_VIDEO);
    width = WIDTH;
    height = HEIGHT;

    window = SDL_CreateWindow("Plasma",
                              SDL_WINDOWPOS_UNDEFINED,
                              SDL_WINDOWPOS_UNDEFINED,
                              width, height,
                              SDL_WINDOW_RESIZABLE);

    screen = SDL_GetWindowSurface(window);

    create_surface();

    initialize_plasma();

#if PRINT_FPS
    start_time = SDL_GetTicks();
#endif
#ifdef __EMSCRIPTEN__
    emscripten_set_main_loop(gameloop, 0, 1);
#else
    while (!gameover)
    {
        gameloop();
#if CAP_SPEED
        SDL_Delay(1);
#endif
    }
#endif

    SDL_FreeSurface(screen);
    SDL_FreeSurface(surface);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
